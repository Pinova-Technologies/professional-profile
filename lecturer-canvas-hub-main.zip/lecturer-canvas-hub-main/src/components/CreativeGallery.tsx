import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Palette, Paintbrush } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import painting1 from "@/assets/painting1.jpg";
import painting2 from "@/assets/painting2.jpg";
import craft1 from "@/assets/craft1.jpg";

interface CreativeWork {
  id: string;
  title: string;
  description: string | null;
  type: string;
  image_url: string;
  year: number | null;
}

const CreativeGallery = () => {
  const [works, setWorks] = useState<CreativeWork[]>([]);
  const [filter, setFilter] = useState<string>("All");
  const { toast } = useToast();

  const imageMap: { [key: string]: string } = {
    '/placeholder-painting1.jpg': painting1,
    '/placeholder-painting2.jpg': painting2,
    '/placeholder-craft1.jpg': craft1,
  };

  useEffect(() => {
    fetchWorks();
  }, []);

  const fetchWorks = async () => {
    const { data, error } = await supabase
      .from('creative_works')
      .select('*')
      .order('year', { ascending: false });

    if (error) {
      toast({
        title: "Error",
        description: "Failed to load creative works",
        variant: "destructive",
      });
      return;
    }

    setWorks(data || []);
  };

  const filteredWorks = works.filter(work => 
    filter === "All" || work.type === filter.toLowerCase()
  );

  return (
    <section id="creative" className="py-20 bg-gradient-to-br from-accent/5 to-accent/10">
      <div className="container mx-auto px-4">
        <h2 className="font-serif text-4xl md:text-5xl font-bold text-center mb-4">
          Creative Works
        </h2>
        <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
          A collection of paintings and crafts that express my artistic journey
        </p>

        <div className="flex justify-center gap-4 mb-12">
          <Button
            variant={filter === "All" ? "default" : "outline"}
            onClick={() => setFilter("All")}
            className="transition-all duration-300"
          >
            All Works
          </Button>
          <Button
            variant={filter === "Paintings" ? "default" : "outline"}
            onClick={() => setFilter("Paintings")}
            className="gap-2 transition-all duration-300"
          >
            <Palette className="w-4 h-4" />
            Paintings
          </Button>
          <Button
            variant={filter === "Crafts" ? "default" : "outline"}
            onClick={() => setFilter("Crafts")}
            className="gap-2 transition-all duration-300"
          >
            <Paintbrush className="w-4 h-4" />
            Crafts
          </Button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {filteredWorks.map((work) => (
            <Card 
              key={work.id} 
              className="overflow-hidden group hover:shadow-elegant transition-all duration-500 hover:-translate-y-2"
            >
              <div className="aspect-square overflow-hidden">
                <img
                  src={imageMap[work.image_url] || work.image_url}
                  alt={work.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-serif text-xl font-semibold">{work.title}</h3>
                  {work.year && (
                    <span className="text-sm text-muted-foreground">{work.year}</span>
                  )}
                </div>
                {work.description && (
                  <p className="text-sm text-muted-foreground">{work.description}</p>
                )}
                <div className="mt-3">
                  <span className="inline-flex items-center gap-1 text-xs bg-accent/20 text-accent px-2 py-1 rounded">
                    {work.type === 'painting' ? <Palette className="w-3 h-3" /> : <Paintbrush className="w-3 h-3" />}
                    {work.type.charAt(0).toUpperCase() + work.type.slice(1)}
                  </span>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {filteredWorks.length === 0 && (
          <div className="text-center text-muted-foreground py-12">
            No creative works found in this category.
          </div>
        )}
      </div>
    </section>
  );
};

export default CreativeGallery;
