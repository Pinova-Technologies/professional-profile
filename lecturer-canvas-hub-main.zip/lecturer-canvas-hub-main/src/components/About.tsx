import { GraduationCap, BookOpen, Award } from "lucide-react";
import { Card } from "./ui/card";

const About = () => {
  const education = [
    { year: "2015", degree: "Ph.D. in Educational Psychology", institution: "Stanford University" },
    { year: "2010", degree: "M.A. in Teaching and Learning", institution: "Harvard University" },
    { year: "2008", degree: "B.A. in Education", institution: "University of Oxford" },
  ];

  const expertise = [
    "Educational Technology",
    "Digital Learning Environments",
    "Pedagogical Innovation",
    "Cross-Cultural Communication",
    "Assessment Strategies",
    "Student Engagement"
  ];

  return (
    <section id="about" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <h2 className="font-serif text-4xl md:text-5xl font-bold text-center mb-12 text-foreground">
          About Me
        </h2>
        
        <div className="max-w-4xl mx-auto mb-16">
          <p className="text-lg text-muted-foreground leading-relaxed text-center">
            As a dedicated university lecturer, I am passionate about transforming education through innovative 
            teaching methods and meaningful research. My work focuses on enhancing student engagement and learning 
            outcomes in the digital age. Beyond academia, I find balance and inspiration through creative pursuits 
            in painting and crafts, which inform my holistic approach to education.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          <Card className="p-8 hover:shadow-elegant transition-all duration-300">
            <div className="flex items-center gap-3 mb-6">
              <GraduationCap className="w-8 h-8 text-primary" />
              <h3 className="font-serif text-2xl font-semibold">Education</h3>
            </div>
            <div className="space-y-6">
              {education.map((edu, index) => (
                <div key={index} className="border-l-2 border-primary pl-4">
                  <div className="text-sm text-primary font-semibold mb-1">{edu.year}</div>
                  <div className="font-medium mb-1">{edu.degree}</div>
                  <div className="text-sm text-muted-foreground">{edu.institution}</div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-8 hover:shadow-elegant transition-all duration-300">
            <div className="flex items-center gap-3 mb-6">
              <Award className="w-8 h-8 text-accent" />
              <h3 className="font-serif text-2xl font-semibold">Areas of Expertise</h3>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {expertise.map((area, index) => (
                <div 
                  key={index}
                  className="flex items-start gap-2"
                >
                  <BookOpen className="w-4 h-4 text-accent mt-1 flex-shrink-0" />
                  <span className="text-sm">{area}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default About;
