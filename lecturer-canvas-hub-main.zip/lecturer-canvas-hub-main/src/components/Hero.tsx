import { ArrowDown } from "lucide-react";
import { Button } from "./ui/button";
import heroImage from "@/assets/hero-bg.jpg";

const Hero = () => {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-primary/90 via-primary/70 to-accent/60" />
      </div>
      
      <div className="relative z-10 container mx-auto px-4 text-center">
        <h1 className="font-serif text-5xl md:text-7xl font-bold text-white mb-6 animate-fade-in">
          Dr. Sarah Mitchell
        </h1>
        <p className="text-xl md:text-2xl text-white/90 mb-4 font-light">
          University Lecturer | Researcher | Artist
        </p>
        <p className="text-lg text-white/80 max-w-2xl mx-auto mb-8">
          Bridging academic excellence with creative expression through research, teaching, and artistic passion
        </p>
        
        <div className="flex flex-wrap gap-4 justify-center">
          <Button 
            size="lg" 
            className="bg-white text-primary hover:bg-white/90 shadow-elegant transition-all duration-300 hover:scale-105"
            onClick={() => scrollToSection('research')}
          >
            View Research
          </Button>
          <Button 
            size="lg" 
            variant="outline"
            className="border-white text-white hover:bg-white hover:text-primary transition-all duration-300 hover:scale-105"
            onClick={() => scrollToSection('creative')}
          >
            Creative Works
          </Button>
        </div>
        
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <ArrowDown className="w-8 h-8 text-white/60" />
        </div>
      </div>
    </section>
  );
};

export default Hero;
