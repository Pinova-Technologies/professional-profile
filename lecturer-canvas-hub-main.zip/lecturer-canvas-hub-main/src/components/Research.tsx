import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { FileText, Calendar, Users } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ResearchPaper {
  id: string;
  title: string;
  abstract: string;
  category: string;
  year: number;
  authors: string;
  publication: string | null;
  pdf_url: string | null;
}

const Research = () => {
  const [papers, setPapers] = useState<ResearchPaper[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [selectedYear, setSelectedYear] = useState<string>("All");
  const { toast } = useToast();

  useEffect(() => {
    fetchPapers();
  }, []);

  const fetchPapers = async () => {
    const { data, error } = await supabase
      .from('research_papers')
      .select('*')
      .order('year', { ascending: false });

    if (error) {
      toast({
        title: "Error",
        description: "Failed to load research papers",
        variant: "destructive",
      });
      return;
    }

    setPapers(data || []);
  };

  const categories = ["All", ...Array.from(new Set(papers.map(p => p.category)))];
  const years = ["All", ...Array.from(new Set(papers.map(p => p.year.toString())))];

  const filteredPapers = papers.filter(paper => {
    const categoryMatch = selectedCategory === "All" || paper.category === selectedCategory;
    const yearMatch = selectedYear === "All" || paper.year.toString() === selectedYear;
    return categoryMatch && yearMatch;
  });

  return (
    <section id="research" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <h2 className="font-serif text-4xl md:text-5xl font-bold text-center mb-4">
          Research Publications
        </h2>
        <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
          Explore my peer-reviewed publications and ongoing research in educational innovation
        </p>

        <div className="flex flex-wrap gap-4 justify-center mb-12">
          <div className="flex flex-wrap gap-2">
            <span className="text-sm font-medium self-center mr-2">Category:</span>
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="transition-all duration-300"
              >
                {category}
              </Button>
            ))}
          </div>
          
          <div className="flex flex-wrap gap-2">
            <span className="text-sm font-medium self-center mr-2">Year:</span>
            {years.map((year) => (
              <Button
                key={year}
                variant={selectedYear === year ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedYear(year)}
                className="transition-all duration-300"
              >
                {year}
              </Button>
            ))}
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6 max-w-6xl mx-auto">
          {filteredPapers.map((paper) => (
            <Card key={paper.id} className="p-6 hover:shadow-elegant transition-all duration-300 hover:-translate-y-1">
              <div className="flex items-start gap-3 mb-4">
                <FileText className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-serif text-xl font-semibold mb-2">{paper.title}</h3>
                  <div className="flex flex-wrap gap-2 mb-3">
                    <span className="inline-flex items-center gap-1 text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                      <Calendar className="w-3 h-3" />
                      {paper.year}
                    </span>
                    <span className="inline-flex items-center gap-1 text-xs bg-accent/10 text-accent px-2 py-1 rounded">
                      {paper.category}
                    </span>
                  </div>
                </div>
              </div>
              
              <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
                {paper.abstract}
              </p>
              
              <div className="space-y-2 text-sm">
                <div className="flex items-start gap-2">
                  <Users className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                  <span className="text-muted-foreground">{paper.authors}</span>
                </div>
                {paper.publication && (
                  <div className="text-muted-foreground italic">
                    Published in: {paper.publication}
                  </div>
                )}
              </div>

              {paper.pdf_url && (
                <Button variant="outline" size="sm" className="mt-4 w-full" asChild>
                  <a href={paper.pdf_url} target="_blank" rel="noopener noreferrer">
                    View PDF
                  </a>
                </Button>
              )}
            </Card>
          ))}
        </div>

        {filteredPapers.length === 0 && (
          <div className="text-center text-muted-foreground py-12">
            No research papers found matching the selected filters.
          </div>
        )}
      </div>
    </section>
  );
};

export default Research;
