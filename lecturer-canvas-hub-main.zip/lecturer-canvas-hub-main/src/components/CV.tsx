import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Download } from "lucide-react";

const CV = () => {
  const handleDownload = () => {
    // Create a simple CV download trigger
    // In a real implementation, this would link to an actual PDF file
    const link = document.createElement('a');
    link.href = '/cv-dr-sarah-mitchell.pdf'; // This would be a real PDF file in production
    link.download = 'CV-Dr-Sarah-Mitchell.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <section className="py-20 bg-gradient-to-br from-primary/5 to-primary/10">
      <div className="container mx-auto px-4">
        <Card className="max-w-4xl mx-auto p-12 text-center hover:shadow-elegant transition-all duration-300">
          <h2 className="font-serif text-3xl md:text-4xl font-bold mb-4">
            Curriculum Vitae
          </h2>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            Download my complete CV for detailed information about my academic background, 
            publications, research experience, and professional achievements.
          </p>
          <Button 
            size="lg" 
            onClick={handleDownload}
            className="gap-2 shadow-elegant hover:scale-105 transition-all duration-300"
          >
            <Download className="w-5 h-5" />
            Download CV (PDF)
          </Button>
        </Card>
      </div>
    </section>
  );
};

export default CV;
