import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Plus, Trash2, Edit } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

interface ResearchPaper {
  id: string;
  title: string;
  abstract: string;
  category: string;
  year: number;
  authors: string;
  publication: string | null;
  pdf_url: string | null;
}

const ResearchManager = () => {
  const [papers, setPapers] = useState<ResearchPaper[]>([]);
  const [title, setTitle] = useState('');
  const [abstract, setAbstract] = useState('');
  const [category, setCategory] = useState('');
  const [year, setYear] = useState(new Date().getFullYear());
  const [authors, setAuthors] = useState('');
  const [publication, setPublication] = useState('');
  const [pdfUrl, setPdfUrl] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchPapers();
  }, []);

  const fetchPapers = async () => {
    const { data, error } = await supabase
      .from('research_papers')
      .select('*')
      .order('year', { ascending: false });

    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to fetch research papers',
        variant: 'destructive',
      });
    } else if (data) {
      setPapers(data);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const paperData = {
      title,
      abstract,
      category,
      year,
      authors,
      publication: publication || null,
      pdf_url: pdfUrl || null,
    };

    if (editingId) {
      const { error } = await supabase
        .from('research_papers')
        .update(paperData)
        .eq('id', editingId);

      if (error) {
        toast({
          title: 'Error',
          description: 'Failed to update paper',
          variant: 'destructive',
        });
      } else {
        toast({ title: 'Success', description: 'Paper updated successfully' });
      }
    } else {
      const { error } = await supabase
        .from('research_papers')
        .insert(paperData);

      if (error) {
        toast({
          title: 'Error',
          description: 'Failed to create paper',
          variant: 'destructive',
        });
      } else {
        toast({ title: 'Success', description: 'Paper created successfully' });
      }
    }

    resetForm();
    fetchPapers();
    setIsOpen(false);
  };

  const handleEdit = (paper: ResearchPaper) => {
    setTitle(paper.title);
    setAbstract(paper.abstract);
    setCategory(paper.category);
    setYear(paper.year);
    setAuthors(paper.authors);
    setPublication(paper.publication || '');
    setPdfUrl(paper.pdf_url || '');
    setEditingId(paper.id);
    setIsOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this paper?')) return;

    const { error } = await supabase.from('research_papers').delete().eq('id', id);

    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete paper',
        variant: 'destructive',
      });
    } else {
      toast({ title: 'Success', description: 'Paper deleted successfully' });
      fetchPapers();
    }
  };

  const resetForm = () => {
    setTitle('');
    setAbstract('');
    setCategory('');
    setYear(new Date().getFullYear());
    setAuthors('');
    setPublication('');
    setPdfUrl('');
    setEditingId(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Research Papers</h2>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm} className="gap-2">
              <Plus className="w-4 h-4" />
              Add Research Paper
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingId ? 'Edit Research Paper' : 'Create Research Paper'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="authors">Authors</Label>
                <Input
                  id="authors"
                  value={authors}
                  onChange={(e) => setAuthors(e.target.value)}
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Input
                    id="category"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="year">Year</Label>
                  <Input
                    id="year"
                    type="number"
                    value={year}
                    onChange={(e) => setYear(parseInt(e.target.value))}
                    required
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="publication">Publication</Label>
                <Input
                  id="publication"
                  value={publication}
                  onChange={(e) => setPublication(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="abstract">Abstract</Label>
                <Textarea
                  id="abstract"
                  value={abstract}
                  onChange={(e) => setAbstract(e.target.value)}
                  rows={5}
                  required
                />
              </div>
              <div>
                <Label htmlFor="pdfUrl">PDF URL</Label>
                <Input
                  id="pdfUrl"
                  type="url"
                  value={pdfUrl}
                  onChange={(e) => setPdfUrl(e.target.value)}
                  placeholder="https://..."
                />
              </div>
              <div className="flex gap-2">
                <Button type="submit" className="flex-1">
                  {editingId ? 'Update' : 'Create'}
                </Button>
                <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {papers.map((paper) => (
          <Card key={paper.id} className="p-6">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <h3 className="text-xl font-bold mb-2">{paper.title}</h3>
                <p className="text-sm text-muted-foreground mb-2">
                  {paper.authors} ({paper.year})
                </p>
                <p className="text-sm mb-2">{paper.abstract}</p>
                <span className="inline-block px-2 py-1 text-xs bg-primary/10 rounded">
                  {paper.category}
                </span>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => handleEdit(paper)}>
                  <Edit className="w-4 h-4" />
                </Button>
                <Button variant="destructive" size="sm" onClick={() => handleDelete(paper.id)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ResearchManager;
