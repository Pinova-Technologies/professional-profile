import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Upload, Download, Trash2 } from 'lucide-react';

const CVManager = () => {
  const [files, setFiles] = useState<any[]>([]);
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchFiles();
  }, []);

  const fetchFiles = async () => {
    const { data, error } = await supabase.storage
      .from('cv-files')
      .list('', { sortBy: { column: 'created_at', order: 'desc' } });

    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to fetch CV files',
        variant: 'destructive',
      });
    } else if (data) {
      setFiles(data);
    }
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      toast({
        title: 'Error',
        description: 'Only PDF files are allowed',
        variant: 'destructive',
      });
      return;
    }

    setUploading(true);

    const fileName = `cv-${Date.now()}.pdf`;
    const { error } = await supabase.storage
      .from('cv-files')
      .upload(fileName, file);

    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to upload CV',
        variant: 'destructive',
      });
    } else {
      toast({ title: 'Success', description: 'CV uploaded successfully' });
      fetchFiles();
    }

    setUploading(false);
    e.target.value = '';
  };

  const handleDownload = async (fileName: string) => {
    const { data } = supabase.storage
      .from('cv-files')
      .getPublicUrl(fileName);

    if (data) {
      window.open(data.publicUrl, '_blank');
    }
  };

  const handleDelete = async (fileName: string) => {
    if (!confirm('Are you sure you want to delete this CV?')) return;

    const { error } = await supabase.storage
      .from('cv-files')
      .remove([fileName]);

    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete CV',
        variant: 'destructive',
      });
    } else {
      toast({ title: 'Success', description: 'CV deleted successfully' });
      fetchFiles();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">CV/Resume Manager</h2>
        <div>
          <Input
            type="file"
            accept=".pdf"
            onChange={handleUpload}
            disabled={uploading}
            className="hidden"
            id="cv-upload"
          />
          <Label htmlFor="cv-upload">
            <Button asChild disabled={uploading}>
              <span className="gap-2 cursor-pointer">
                <Upload className="w-4 h-4" />
                {uploading ? 'Uploading...' : 'Upload CV'}
              </span>
            </Button>
          </Label>
        </div>
      </div>

      <div className="grid gap-4">
        {files.map((file) => (
          <Card key={file.name} className="p-6">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-bold">{file.name}</h3>
                <p className="text-sm text-muted-foreground">
                  Size: {(file.metadata?.size / 1024).toFixed(2)} KB
                </p>
                <p className="text-sm text-muted-foreground">
                  Uploaded: {new Date(file.created_at).toLocaleDateString()}
                </p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => handleDownload(file.name)}>
                  <Download className="w-4 h-4" />
                </Button>
                <Button variant="destructive" size="sm" onClick={() => handleDelete(file.name)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        ))}
        {files.length === 0 && (
          <p className="text-center text-muted-foreground py-8">
            No CV files uploaded yet. Upload your first CV using the button above.
          </p>
        )}
      </div>
    </div>
  );
};

export default CVManager;
