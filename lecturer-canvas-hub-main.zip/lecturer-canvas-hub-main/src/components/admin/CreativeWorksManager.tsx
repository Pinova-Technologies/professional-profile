import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Plus, Trash2, Edit } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface CreativeWork {
  id: string;
  title: string;
  description: string | null;
  type: string;
  image_url: string;
  year: number | null;
}

const CreativeWorksManager = () => {
  const [works, setWorks] = useState<CreativeWork[]>([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState('painting');
  const [imageUrl, setImageUrl] = useState('');
  const [year, setYear] = useState(new Date().getFullYear());
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchWorks();
  }, []);

  const fetchWorks = async () => {
    const { data, error } = await supabase
      .from('creative_works')
      .select('*')
      .order('year', { ascending: false });

    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to fetch creative works',
        variant: 'destructive',
      });
    } else if (data) {
      setWorks(data);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const workData = {
      title,
      description: description || null,
      type,
      image_url: imageUrl,
      year: year || null,
    };

    if (editingId) {
      const { error } = await supabase
        .from('creative_works')
        .update(workData)
        .eq('id', editingId);

      if (error) {
        toast({
          title: 'Error',
          description: 'Failed to update work',
          variant: 'destructive',
        });
      } else {
        toast({ title: 'Success', description: 'Work updated successfully' });
      }
    } else {
      const { error } = await supabase
        .from('creative_works')
        .insert(workData);

      if (error) {
        toast({
          title: 'Error',
          description: 'Failed to create work',
          variant: 'destructive',
        });
      } else {
        toast({ title: 'Success', description: 'Work created successfully' });
      }
    }

    resetForm();
    fetchWorks();
    setIsOpen(false);
  };

  const handleEdit = (work: CreativeWork) => {
    setTitle(work.title);
    setDescription(work.description || '');
    setType(work.type);
    setImageUrl(work.image_url);
    setYear(work.year || new Date().getFullYear());
    setEditingId(work.id);
    setIsOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this work?')) return;

    const { error } = await supabase.from('creative_works').delete().eq('id', id);

    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete work',
        variant: 'destructive',
      });
    } else {
      toast({ title: 'Success', description: 'Work deleted successfully' });
      fetchWorks();
    }
  };

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setType('painting');
    setImageUrl('');
    setYear(new Date().getFullYear());
    setEditingId(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Creative Works</h2>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm} className="gap-2">
              <Plus className="w-4 h-4" />
              Add Creative Work
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingId ? 'Edit Creative Work' : 'Create Creative Work'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="type">Type</Label>
                  <Select value={type} onValueChange={setType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="painting">Painting</SelectItem>
                      <SelectItem value="craft">Craft</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="year">Year</Label>
                  <Input
                    id="year"
                    type="number"
                    value={year}
                    onChange={(e) => setYear(parseInt(e.target.value))}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="imageUrl">Image URL</Label>
                <Input
                  id="imageUrl"
                  type="url"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  placeholder="https://..."
                  required
                />
              </div>
              <div className="flex gap-2">
                <Button type="submit" className="flex-1">
                  {editingId ? 'Update' : 'Create'}
                </Button>
                <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {works.map((work) => (
          <Card key={work.id} className="p-6">
            <div className="flex gap-4">
              <img
                src={work.image_url}
                alt={work.title}
                className="w-32 h-32 object-cover rounded"
              />
              <div className="flex-1">
                <h3 className="text-xl font-bold mb-2">{work.title}</h3>
                <p className="text-sm text-muted-foreground mb-2">
                  {work.type} {work.year && `(${work.year})`}
                </p>
                {work.description && <p className="text-sm">{work.description}</p>}
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => handleEdit(work)}>
                  <Edit className="w-4 h-4" />
                </Button>
                <Button variant="destructive" size="sm" onClick={() => handleDelete(work.id)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default CreativeWorksManager;
