import { useAuth } from '@/hooks/useAuth';
import { Navigate } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { LogOut } from 'lucide-react';
import BlogManager from '@/components/admin/BlogManager';
import ResearchManager from '@/components/admin/ResearchManager';
import CreativeWorksManager from '@/components/admin/CreativeWorksManager';
import CVManager from '@/components/admin/CVManager';

const Admin = () => {
  const { isAdmin, loading, signOut } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAdmin) {
    return <Navigate to="/auth" replace />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-primary/5">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="font-serif text-4xl font-bold">Admin Panel</h1>
          <Button onClick={signOut} variant="outline" className="gap-2">
            <LogOut className="w-4 h-4" />
            Sign Out
          </Button>
        </div>

        <Tabs defaultValue="blogs" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="blogs">Blogs</TabsTrigger>
            <TabsTrigger value="research">Research Papers</TabsTrigger>
            <TabsTrigger value="creative">Creative Works</TabsTrigger>
            <TabsTrigger value="cv">CV</TabsTrigger>
          </TabsList>

          <TabsContent value="blogs">
            <BlogManager />
          </TabsContent>

          <TabsContent value="research">
            <ResearchManager />
          </TabsContent>

          <TabsContent value="creative">
            <CreativeWorksManager />
          </TabsContent>

          <TabsContent value="cv">
            <CVManager />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Admin;
