import Navigation from "@/components/Navigation";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Research from "@/components/Research";
import CreativeGallery from "@/components/CreativeGallery";
import CV from "@/components/CV";
import Appointment from "@/components/Appointment";
import Contact from "@/components/Contact";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      <Hero />
      <About />
      <Research />
      <CreativeGallery />
      <CV />
      <Appointment />
      <Contact />
      
      <footer className="bg-primary text-primary-foreground py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="font-serif text-lg mb-2">Dr. Sarah Mitchell</p>
          <p className="text-sm opacity-80">
            University Lecturer | Researcher | Artist
          </p>
          <p className="text-xs opacity-60 mt-4">
            © {new Date().getFullYear()} All rights reserved
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
