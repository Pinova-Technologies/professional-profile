import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@4.0.1";

const resend = new Resend(Deno.env.get("RESEND_API_KEY") as string);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface AppointmentRequest {
  name: string;
  email: string;
  purpose: string;
  date: string;
  message?: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { name, email, purpose, date, message }: AppointmentRequest = await req.json();

    const formattedDate = new Date(date).toLocaleString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });

    // Send email to the lecturer
    const lecturerEmail = await resend.emails.send({
      from: "Portfolio <onboarding@resend.dev>",
      to: ["sarah.mitchell@university.edu"], // Replace with actual email
      subject: "New Appointment Request",
      html: `
        <h1>New Appointment Request</h1>
        <p><strong>From:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Purpose:</strong> ${purpose}</p>
        <p><strong>Preferred Date:</strong> ${formattedDate}</p>
        ${message ? `<p><strong>Additional Information:</strong> ${message}</p>` : ''}
        <p>Please review and confirm this appointment at your earliest convenience.</p>
      `,
    });

    // Send confirmation to the requester
    const requesterEmail = await resend.emails.send({
      from: "Dr. Sarah Mitchell <onboarding@resend.dev>",
      to: [email],
      subject: "Appointment Request Received",
      html: `
        <h1>Appointment Request Received</h1>
        <p>Dear ${name},</p>
        <p>Thank you for requesting an appointment. I have received your request with the following details:</p>
        <p><strong>Purpose:</strong> ${purpose}</p>
        <p><strong>Preferred Date:</strong> ${formattedDate}</p>
        ${message ? `<p><strong>Your Message:</strong> ${message}</p>` : ''}
        <p>I will review your request and send you a confirmation email shortly.</p>
        <p>Best regards,<br>Dr. Sarah Mitchell</p>
      `,
    });

    console.log("Emails sent successfully:", { lecturerEmail, requesterEmail });

    return new Response(
      JSON.stringify({ 
        success: true, 
        lecturerEmail, 
        requesterEmail 
      }), 
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders,
        },
      }
    );
  } catch (error: any) {
    console.error("Error in send-appointment-email function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
