-- Remove public SELECT policy
DROP POLICY "Appointments are viewable by everyone" ON appointments;

-- Add admin-only SELECT policy
CREATE POLICY "Admins can view all appointments"
ON appointments
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));