-- Create research papers table
CREATE TABLE public.research_papers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  abstract TEXT NOT NULL,
  category TEXT NOT NULL,
  year INTEGER NOT NULL,
  authors TEXT NOT NULL,
  publication TEXT,
  pdf_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create creative works table
CREATE TABLE public.creative_works (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  type TEXT NOT NULL, -- 'painting' or 'craft'
  image_url TEXT NOT NULL,
  year INTEGER,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create appointments table
CREATE TABLE public.appointments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  date TIMESTAMP WITH TIME ZONE NOT NULL,
  purpose TEXT NOT NULL,
  message TEXT,
  status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'confirmed', 'cancelled'
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create contact messages table
CREATE TABLE public.contact_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  subject TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.research_papers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.creative_works ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contact_messages ENABLE ROW LEVEL SECURITY;

-- RLS Policies for research_papers (public read)
CREATE POLICY "Research papers are viewable by everyone"
ON public.research_papers FOR SELECT
USING (true);

-- RLS Policies for creative_works (public read)
CREATE POLICY "Creative works are viewable by everyone"
ON public.creative_works FOR SELECT
USING (true);

-- RLS Policies for appointments (anyone can create, only authenticated users can view)
CREATE POLICY "Anyone can create appointments"
ON public.appointments FOR INSERT
WITH CHECK (true);

CREATE POLICY "Appointments are viewable by everyone"
ON public.appointments FOR SELECT
USING (true);

-- RLS Policies for contact_messages (anyone can create)
CREATE POLICY "Anyone can send contact messages"
ON public.contact_messages FOR INSERT
WITH CHECK (true);

-- Insert sample research papers
INSERT INTO public.research_papers (title, abstract, category, year, authors, publication) VALUES
('The Impact of Digital Learning on Student Engagement', 'This study explores how digital learning tools affect student participation and academic performance in higher education settings.', 'Education Technology', 2023, 'Dr. Sarah Mitchell, Dr. James Chen', 'Journal of Educational Research'),
('Innovative Teaching Methods in Modern Academia', 'An analysis of contemporary pedagogical approaches and their effectiveness in university-level courses.', 'Pedagogy', 2022, 'Dr. Sarah Mitchell', 'International Journal of Teaching'),
('Cross-Cultural Communication in Global Classrooms', 'Examining the challenges and opportunities of multicultural learning environments.', 'Cultural Studies', 2023, 'Dr. Sarah Mitchell, Prof. Maria Rodriguez', 'Education Quarterly'),
('Assessment Strategies for 21st Century Learning', 'Evaluating modern assessment methods and their alignment with contemporary educational goals.', 'Assessment', 2021, 'Dr. Sarah Mitchell', 'Academic Assessment Review');

-- Insert sample creative works
INSERT INTO public.creative_works (title, description, type, image_url, year) VALUES
('Azure Dreams', 'Abstract watercolor exploring the depths of blue and purple tones', 'painting', '/placeholder-painting1.jpg', 2023),
('Sunset Symphony', 'Vibrant expression of warmth through terracotta and amber hues', 'painting', '/placeholder-painting2.jpg', 2023),
('Geometric Harmony', 'Mixed media craft featuring intricate geometric patterns', 'craft', '/placeholder-craft1.jpg', 2022);